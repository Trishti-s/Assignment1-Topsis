# Topsis-Trishti-10155792

This package implements the TOPSIS method.

## Installation
pip install Topsis-Trishti-10155792

## Usage
topsis input.csv "1,1,1" "+,+,-" output.csv
